from tkinter import *
import tkinter as tk
from tkinter import ttk

from survey import *
from survey import score
import time
# show the survey
survey()
s = score()
print(s)

time.sleep(3)


exec(open('result.py').read())